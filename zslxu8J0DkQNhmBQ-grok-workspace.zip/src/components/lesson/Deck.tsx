import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ChevronLeft,
  ChevronRight,
  GraduationCap,
  List,
  Maximize,
  Minimize,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { SlideView } from "@/components/lesson/slides";
import { DeckContext } from "@/components/lesson/deck-context";
import { SECTIONS, SLIDES } from "@/data/lesson";
import { cn } from "@/lib/utils";

const INDEX_KEY = "chem7-slide";

export function Deck() {
  const [index, setIndex] = useState(0);
  const [teacher, setTeacher] = useState(false);
  const [menu, setMenu] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);

  useEffect(() => {
    try {
      const saved = Number(localStorage.getItem(INDEX_KEY));
      if (Number.isFinite(saved) && saved >= 0 && saved < SLIDES.length) {
        setIndex(saved);
      }
      setTeacher(localStorage.getItem("chem7-teacher") === "1");
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(INDEX_KEY, String(index));
  }, [index]);

  useEffect(() => {
    localStorage.setItem("chem7-teacher", teacher ? "1" : "0");
  }, [teacher]);

  const go = useCallback((i: number) => {
    setIndex(Math.min(SLIDES.length - 1, Math.max(0, i)));
    setMenu(false);
  }, []);

  const next = useCallback(() => go(index + 1), [go, index]);
  const prev = useCallback(() => go(index - 1), [go, index]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.key === "ArrowRight" || e.key === "PageDown") {
        e.preventDefault();
        next();
      } else if (e.key === "ArrowLeft" || e.key === "PageUp") {
        e.preventDefault();
        prev();
      } else if (e.key === "Home") {
        go(0);
      } else if (e.key === "End") {
        go(SLIDES.length - 1);
      } else if (e.key === "Escape") {
        setMenu(false);
      } else if (e.key === "m" || e.key === "M" || e.key === "ь") {
        setMenu((v) => !v);
      } else if (e.key === "t" || e.key === "T") {
        setTeacher((v) => !v);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [go, next, prev]);

  useEffect(() => {
    const onFs = () => setFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  const api = useMemo(
    () => ({ index, go, next, prev, teacher }),
    [index, go, next, prev, teacher],
  );

  const slide = SLIDES[index];
  const progress = ((index + 1) / SLIDES.length) * 100;

  return (
    <DeckContext.Provider value={api}>
      <div className="paper-bg flex h-dvh flex-col text-ink">
        <header className="no-print relative z-20 flex h-14 shrink-0 items-center gap-3 border-b border-border px-3 md:px-5">
          <Button
            type="button"
            variant="ghost"
            size="icon-sm"
            aria-label="Слайдтар тізімі"
            onClick={() => setMenu(true)}
          >
            <List />
          </Button>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium">{slide.title}</p>
            <p className="truncate text-xs text-muted">{slide.kicker}</p>
          </div>
          <Button
            type="button"
            variant={teacher ? "primary" : "ghost"}
            size="sm"
            className="hidden sm:inline-flex"
            onClick={() => setTeacher((v) => !v)}
          >
            <GraduationCap />
            Мұғалім
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="icon-sm"
            aria-label={fullscreen ? "Толық экраннан шығу" : "Толық экран"}
            onClick={() => {
              if (document.fullscreenElement) void document.exitFullscreen();
              else void document.documentElement.requestFullscreen();
            }}
          >
            {fullscreen ? <Minimize /> : <Maximize />}
          </Button>
          <span className="hidden tabular-nums text-sm text-muted md:inline">
            {index + 1}/{SLIDES.length}
          </span>
          <div className="absolute inset-x-0 bottom-0 h-px bg-border">
            <div
              className="h-px bg-accent transition-[width] duration-[var(--motion-fast)] ease-[var(--ease-out)]"
              style={{ width: `${progress}%` }}
            />
          </div>
        </header>

        <main
          className="min-h-0 flex-1 overflow-y-auto"
          onTouchStart={(e) => {
            const t = e.changedTouches[0];
            (e.currentTarget as HTMLElement).dataset.sx = String(t.clientX);
            (e.currentTarget as HTMLElement).dataset.sy = String(t.clientY);
          }}
          onTouchEnd={(e) => {
            const el = e.currentTarget;
            const sx = Number(el.dataset.sx ?? 0);
            const sy = Number(el.dataset.sy ?? 0);
            const t = e.changedTouches[0];
            const dx = t.clientX - sx;
            const dy = t.clientY - sy;
            if (Math.abs(dx) > 72 && Math.abs(dx) > Math.abs(dy) * 1.4) {
              if (dx < 0) next();
              else prev();
            }
          }}
        >
          <SlideView id={slide.id} teacher={teacher} />
        </main>

        <footer className="no-print flex h-16 shrink-0 items-center gap-2 border-t border-border px-3 md:px-5">
          <Button
            type="button"
            variant="outline"
            size="icon"
            aria-label="Алдыңғы слайд"
            disabled={index === 0}
            onClick={prev}
          >
            <ChevronLeft />
          </Button>
          <div className="flex min-w-0 flex-1 justify-center gap-1 overflow-x-auto py-1">
            {SLIDES.map((s, i) => (
              <button
                key={s.id}
                type="button"
                aria-label={`${i + 1}. ${s.title}`}
                onClick={() => go(i)}
                className={cn(
                  "h-2.5 w-2.5 shrink-0 rounded-full transition-colors duration-[var(--motion-quick)]",
                  i === index ? "bg-accent" : "bg-border hover:bg-muted",
                )}
              />
            ))}
          </div>
          <Button
            type="button"
            variant="primary"
            className="min-w-11"
            disabled={index === SLIDES.length - 1}
            onClick={next}
          >
            <span className="hidden sm:inline">Келесі</span>
            <ChevronRight />
          </Button>
        </footer>

        {menu ? (
          <div className="no-print fixed inset-0 z-40">
            <button
              type="button"
              className="absolute inset-0 bg-ink/30"
              aria-label="Мәзірді жабу"
              onClick={() => setMenu(false)}
            />
            <aside className="absolute inset-y-0 left-0 flex w-[min(100%,22rem)] flex-col bg-surface shadow-border">
              <div className="flex h-14 items-center justify-between border-b border-border px-4">
                <p className="font-medium">Слайдтар</p>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon-sm"
                  aria-label="Жабу"
                  onClick={() => setMenu(false)}
                >
                  <X />
                </Button>
              </div>
              <nav className="flex-1 overflow-y-auto p-3">
                <button
                  type="button"
                  className={cn(
                    "mb-4 flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm sm:hidden",
                    teacher ? "bg-accent text-accent-fg" : "bg-surface-2",
                  )}
                  onClick={() => setTeacher((v) => !v)}
                >
                  <GraduationCap className="size-4" />
                  Мұғалім режимі {teacher ? "қосулы" : "өшірулі"}
                </button>
                {SECTIONS.map((sec) => (
                  <div key={sec.id} className="mb-4">
                    <p className="px-2 pb-1 text-xs font-semibold tracking-widest text-muted">
                      {sec.label}
                    </p>
                    <ul className="flex flex-col gap-1">
                      {SLIDES.filter((s) => s.section === sec.id).map((s) => {
                        const i = SLIDES.findIndex((x) => x.id === s.id);
                        return (
                          <li key={s.id}>
                            <button
                              type="button"
                              onClick={() => go(i)}
                              className={cn(
                                "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm",
                                i === index
                                  ? "bg-accent text-accent-fg"
                                  : "hover:bg-surface-2",
                              )}
                            >
                              <span className="w-5 tabular-nums text-xs opacity-70">
                                {i + 1}
                              </span>
                              <span className="min-w-0 flex-1 truncate">
                                {s.title}
                              </span>
                            </button>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                ))}
              </nav>
            </aside>
          </div>
        ) : null}
      </div>
    </DeckContext.Provider>
  );
}
