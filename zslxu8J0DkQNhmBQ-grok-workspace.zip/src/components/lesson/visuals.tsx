import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

export function Kicker({ children }: { children: ReactNode }) {
  return (
    <p className="text-xs font-semibold tracking-widest text-accent">{children}</p>
  );
}

export function Panel({
  className,
  children,
}: {
  className?: string;
  children: ReactNode;
}) {
  return (
    <div
      className={cn(
        "rounded-2xl bg-surface p-5 shadow-border md:p-6",
        className,
      )}
    >
      {children}
    </div>
  );
}

export function Photo({
  src,
  alt,
  caption,
  className,
}: {
  src: string;
  alt: string;
  caption?: string;
  className?: string;
}) {
  return (
    <figure className={cn("min-w-0", className)}>
      <img
        src={src}
        alt={alt}
        className="aspect-video w-full rounded-xl object-cover"
      />
      {caption ? (
        <figcaption className="mt-2 text-sm text-muted">{caption}</figcaption>
      ) : null}
    </figure>
  );
}

export function MixVisual({
  kind,
  label,
}: {
  kind: "pure" | "homo" | "hetero";
  label: string;
}) {
  const cells = Array.from({ length: 48 }, (_, i) => {
    const col = i % 8;
    const row = Math.floor(i / 8);
    if (kind === "pure") return "a";
    if (kind === "homo") return (col + row) % 2 === 0 ? "a" : "b";
    return col < 4 ? (row + col < 7 ? "a" : "b") : "b";
  });

  return (
    <div className="rounded-xl bg-surface-2 p-4">
      <div className="grid grid-cols-8 gap-2">
        {cells.map((c, i) => (
          <span
            key={i}
            className={cn(
              "aspect-square rounded-full",
              c === "a" ? "bg-accent" : "bg-ink/35",
            )}
          />
        ))}
      </div>
      <p className="mt-3 text-center text-sm text-muted">{label}</p>
    </div>
  );
}

export function SlideShell({ children }: { children: ReactNode }) {
  return (
    <div
      key="shell"
      className="slide-enter mx-auto flex w-full max-w-6xl flex-col gap-6 px-5 py-6 md:px-10 md:py-8"
    >
      {children}
    </div>
  );
}
