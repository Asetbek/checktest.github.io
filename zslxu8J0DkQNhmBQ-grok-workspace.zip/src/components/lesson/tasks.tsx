import { useEffect, useMemo, useState } from "react";
import { Check, RotateCcw, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  MATCH_ITEMS,
  QUIZ,
  SORT_ITEMS,
  TYPE_ITEMS,
  type QuizQ,
} from "@/data/lesson";

function useChoices(key: string) {
  const [choices, setChoices] = useState<Record<string, string>>({});
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(key);
      if (raw) {
        const parsed = JSON.parse(raw) as {
          choices: Record<string, string>;
          checked: boolean;
        };
        setChoices(parsed.choices ?? {});
        setChecked(Boolean(parsed.checked));
      }
    } catch {
      /* ignore */
    }
  }, [key]);

  useEffect(() => {
    localStorage.setItem(key, JSON.stringify({ choices, checked }));
  }, [key, choices, checked]);

  return { choices, setChoices, checked, setChecked };
}

function cycleValue(current: string | undefined, values: string[]) {
  const i = current ? values.indexOf(current) : -1;
  return values[(i + 1) % values.length];
}

function ScoreBar({
  correct,
  total,
  onReset,
}: {
  correct: number;
  total: number;
  onReset: () => void;
}) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3">
      <p className="text-sm text-muted">
        Нәтиже:{" "}
        <span className="font-semibold text-ink tabular-nums">
          {correct} / {total}
        </span>
      </p>
      <Button type="button" variant="ghost" size="sm" onClick={onReset}>
        <RotateCcw />
        Қайталау
      </Button>
    </div>
  );
}

export function SortTask({ teacher }: { teacher: boolean }) {
  const { choices, setChoices, checked, setChecked } = useChoices("chem7-sort");
  const bins = [
    { id: "pure", label: "Таза зат" },
    { id: "mix", label: "Қоспа" },
  ];

  const correct = SORT_ITEMS.filter((it) => choices[it.id] === it.answer).length;
  const show = checked || teacher;

  return (
    <div className="flex flex-col gap-5">
      <p className="text-muted">
        Затты басыңыз: таза зат пен қоспа арасында ауысады. Сосын тексеріңіз.
      </p>
      <div className="flex flex-wrap gap-2">
        {bins.map((b) => (
          <span
            key={b.id}
            className={cn(
              "rounded-full px-3 py-1 text-sm",
              b.id === "pure" ? "bg-accent text-accent-fg" : "bg-ink text-bg",
            )}
          >
            {b.label}
          </span>
        ))}
      </div>
      <div className="flex flex-wrap gap-2">
        {SORT_ITEMS.map((it) => {
          const val = choices[it.id];
          const ok = val === it.answer;
          return (
            <button
              key={it.id}
              type="button"
              onClick={() => {
                setChecked(false);
                setChoices((c) => ({
                  ...c,
                  [it.id]: cycleValue(c[it.id], ["pure", "mix"]),
                }));
              }}
              className={cn(
                "h-11 rounded-xl px-3.5 text-sm font-medium shadow-border transition-[background-color,color,opacity] duration-[var(--motion-quick)]",
                val === "pure" && "bg-accent text-accent-fg",
                val === "mix" && "bg-ink text-bg",
                !val && "bg-surface text-ink",
                show && val && !ok && "ring-2 ring-bad",
                show && val && ok && "ring-2 ring-ok",
              )}
            >
              {it.label}
            </button>
          );
        })}
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <Button type="button" onClick={() => setChecked(true)}>
          Тексеру
        </Button>
        {show ? (
          <ScoreBar
            correct={correct}
            total={SORT_ITEMS.length}
            onReset={() => {
              setChoices({});
              setChecked(false);
            }}
          />
        ) : null}
      </div>
    </div>
  );
}

export function TypeTask({ teacher }: { teacher: boolean }) {
  const { choices, setChoices, checked, setChecked } = useChoices("chem7-types");
  const show = checked || teacher;
  const correct = TYPE_ITEMS.filter((it) => choices[it.id] === it.answer).length;

  return (
    <div className="flex flex-col gap-5">
      <p className="text-muted">
        Қоспаны басыңыз: біртекті мен әртекті арасында ауысады.
      </p>
      <div className="flex flex-wrap gap-2">
        <span className="rounded-full bg-accent px-3 py-1 text-sm text-accent-fg">
          Біртекті
        </span>
        <span className="rounded-full bg-ink px-3 py-1 text-sm text-bg">
          Әртекті
        </span>
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        {TYPE_ITEMS.map((it) => {
          const val = choices[it.id];
          const ok = val === it.answer;
          return (
            <button
              key={it.id}
              type="button"
              onClick={() => {
                setChecked(false);
                setChoices((c) => ({
                  ...c,
                  [it.id]: cycleValue(c[it.id], ["homo", "hetero"]),
                }));
              }}
              className={cn(
                "flex h-12 items-center justify-between rounded-xl px-4 text-left text-sm font-medium shadow-border",
                val === "homo" && "bg-accent text-accent-fg",
                val === "hetero" && "bg-ink text-bg",
                !val && "bg-surface text-ink",
                show && val && !ok && "ring-2 ring-bad",
                show && val && ok && "ring-2 ring-ok",
              )}
            >
              <span>{it.label}</span>
              <span className="text-xs opacity-80">
                {val === "homo" ? "біртекті" : val === "hetero" ? "әртекті" : "—"}
              </span>
            </button>
          );
        })}
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <Button type="button" onClick={() => setChecked(true)}>
          Тексеру
        </Button>
        {show ? (
          <ScoreBar
            correct={correct}
            total={TYPE_ITEMS.length}
            onReset={() => {
              setChoices({});
              setChecked(false);
            }}
          />
        ) : null}
      </div>
    </div>
  );
}

export function MatchTask({ teacher }: { teacher: boolean }) {
  const { choices, setChoices, checked, setChecked } = useChoices("chem7-match");
  const show = checked || teacher;
  const correct = MATCH_ITEMS.filter((it) => choices[it.id] === it.answer).length;

  return (
    <div className="flex flex-col gap-4">
      {MATCH_ITEMS.map((it) => {
        const val = choices[it.id];
        const ok = val === it.answer;
        return (
          <div key={it.id} className="rounded-2xl bg-surface p-4 shadow-border">
            <p className="mb-3 font-medium">{it.mixture}</p>
            <div className="flex flex-col gap-2">
              {it.options.map((opt) => {
                const selected = val === opt;
                const isAnswer = opt === it.answer;
                return (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => {
                      setChecked(false);
                      setChoices((c) => ({ ...c, [it.id]: opt }));
                    }}
                    className={cn(
                      "flex min-h-11 items-center justify-between rounded-xl px-3 text-left text-sm shadow-border",
                      selected ? "bg-accent text-accent-fg" : "bg-bg text-ink",
                      show && isAnswer && "ring-2 ring-ok",
                      show && selected && !ok && "ring-2 ring-bad",
                    )}
                  >
                    <span>{opt}</span>
                    {show && isAnswer ? <Check className="size-4" /> : null}
                    {show && selected && !ok ? <X className="size-4" /> : null}
                  </button>
                );
              })}
            </div>
          </div>
        );
      })}
      <div className="flex flex-wrap items-center gap-3">
        <Button type="button" onClick={() => setChecked(true)}>
          Тексеру
        </Button>
        {show ? (
          <ScoreBar
            correct={correct}
            total={MATCH_ITEMS.length}
            onReset={() => {
              setChoices({});
              setChecked(false);
            }}
          />
        ) : null}
      </div>
    </div>
  );
}

export function QuizTask({ teacher }: { teacher: boolean }) {
  const [i, setI] = useState(0);
  const [picked, setPicked] = useState<Record<string, number>>({});
  const [done, setDone] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem("chem7-quiz");
      if (raw) {
        const parsed = JSON.parse(raw) as {
          picked: Record<string, number>;
          done: boolean;
          i: number;
        };
        setPicked(parsed.picked ?? {});
        setDone(Boolean(parsed.done));
        setI(parsed.i ?? 0);
      }
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("chem7-quiz", JSON.stringify({ picked, done, i }));
  }, [picked, done, i]);

  const q: QuizQ = QUIZ[i];
  const score = useMemo(
    () => QUIZ.filter((item) => picked[item.id] === item.answer).length,
    [picked],
  );

  if (done || teacher) {
    return (
      <div className="flex flex-col gap-5">
        <div className="rounded-2xl bg-accent px-5 py-6 text-accent-fg">
          <p className="text-xs font-semibold tracking-widest">Нәтиже</p>
          <p className="mt-2 font-serif text-display tabular-nums leading-none">
            {score}/{QUIZ.length}
          </p>
          <p className="mt-3 text-sm text-accent-fg/80">
            {score >= 7
              ? "Керемет. Тақырыпты берік меңгердіңіз."
              : score >= 5
                ? "Жақсы. Қателескен сұрақтарды глоссариймен салыстырыңыз."
                : "Қайталап шығыңыз. Сабақ слайдтарына оралыңыз."}
          </p>
        </div>
        <div className="flex flex-col gap-3">
          {QUIZ.map((item, idx) => {
            const sel = picked[item.id];
            const ok = sel === item.answer;
            return (
              <div key={item.id} className="rounded-2xl bg-surface p-4 shadow-border">
                <p className="text-sm font-medium">
                  {idx + 1}. {item.prompt}
                </p>
                <p
                  className={cn(
                    "mt-2 text-sm",
                    ok ? "text-ok" : sel === undefined ? "text-muted" : "text-bad",
                  )}
                >
                  Сіздің жауабыңыз: {sel === undefined ? "—" : item.options[sel]}
                </p>
                {!ok ? (
                  <p className="mt-1 text-sm text-ink">
                    Дұрысы: {item.options[item.answer]}
                  </p>
                ) : null}
                <p className="mt-2 text-sm text-muted">{item.why}</p>
              </div>
            );
          })}
        </div>
        <Button
          type="button"
          variant="outline"
          onClick={() => {
            setPicked({});
            setDone(false);
            setI(0);
          }}
        >
          <RotateCcw />
          Тестті қайта бастау
        </Button>
      </div>
    );
  }

  const selected = picked[q.id];

  return (
    <div className="flex flex-col gap-5">
      <p className="text-sm text-muted tabular-nums">
        Сұрақ {i + 1} / {QUIZ.length}
      </p>
      <h2 className="font-serif text-title leading-snug">{q.prompt}</h2>
      <div className="flex flex-col gap-2">
        {q.options.map((opt, idx) => (
          <button
            key={opt}
            type="button"
            onClick={() => setPicked((p) => ({ ...p, [q.id]: idx }))}
            className={cn(
              "min-h-12 rounded-xl px-4 py-3 text-left text-sm shadow-border",
              selected === idx ? "bg-accent text-accent-fg" : "bg-surface text-ink",
            )}
          >
            <span className="mr-2 font-semibold tabular-nums">{idx + 1}.</span>
            {opt}
          </button>
        ))}
      </div>
      <div className="flex flex-wrap gap-2">
        <Button
          type="button"
          variant="outline"
          disabled={i === 0}
          onClick={() => setI((n) => Math.max(0, n - 1))}
        >
          Артқа
        </Button>
        {i < QUIZ.length - 1 ? (
          <Button
            type="button"
            disabled={selected === undefined}
            onClick={() => setI((n) => n + 1)}
          >
            Келесі сұрақ
          </Button>
        ) : (
          <Button
            type="button"
            disabled={selected === undefined}
            onClick={() => setDone(true)}
          >
            Нәтижені көру
          </Button>
        )}
      </div>
    </div>
  );
}
