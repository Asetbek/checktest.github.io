import type { ReactNode } from "react";
import {
  Beaker,
  BookOpen,
  Check,
  Droplets,
  Filter,
  FlaskConical,
  Layers,
  Magnet,
  Printer,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  COMPARE_ROWS,
  GLOSSARY,
  HOMEWORK,
  HOMEWORK_KEYS,
  LIFE_EXAMPLES,
  METHODS,
  MIX_EXAMPLES,
  MIX_TRAITS,
  OBJECTIVES,
  PURE_EXAMPLES,
  PURE_TRAITS,
  SLIDES,
} from "@/data/lesson";
import { MatchTask, QuizTask, SortTask, TypeTask } from "@/components/lesson/tasks";
import { Kicker, MixVisual, Panel, Photo, SlideShell } from "@/components/lesson/visuals";
import { useDeck } from "@/components/lesson/deck-context";

export function SlideView({ id, teacher }: { id: string; teacher: boolean }) {
  switch (id) {
    case "cover":
      return <CoverSlide />;
    case "goals":
      return <GoalsSlide />;
    case "nature":
      return <NatureSlide />;
    case "pure":
      return <PureSlide />;
    case "mixture":
      return <MixtureSlide />;
    case "table":
      return <TableSlide />;
    case "types":
      return <TypesSlide />;
    case "examples":
      return <ExamplesSlide />;
    case "methods":
      return <MethodsSlide />;
    case "hetero":
      return <HeteroSlide />;
    case "homo":
      return <HomoSlide />;
    case "experiment":
      return <ExperimentSlide />;
    case "task-sort":
      return (
        <TaskFrame
          kicker="Тапсырма 1"
          title="Таза зат па, қоспа ма?"
        >
          <SortTask teacher={teacher} />
        </TaskFrame>
      );
    case "task-types":
      return (
        <TaskFrame
          kicker="Тапсырма 2"
          title="Біртекті ме, әртекті ме?"
        >
          <TypeTask teacher={teacher} />
        </TaskFrame>
      );
    case "task-match":
      return (
        <TaskFrame
          kicker="Тапсырма 3"
          title="Қоспаны қалай бөлеміз?"
        >
          <MatchTask teacher={teacher} />
        </TaskFrame>
      );
    case "quiz":
      return (
        <TaskFrame kicker="Тест" title="Сегіз сұрақ">
          <QuizTask teacher={teacher} />
        </TaskFrame>
      );
    case "homework":
      return <HomeworkSlide teacher={teacher} />;
    case "glossary":
      return <GlossarySlide />;
    case "thanks":
      return <ThanksSlide />;
    default:
      return null;
  }
}

function TaskFrame({
  kicker,
  title,
  children,
}: {
  kicker: string;
  title: string;
  children: ReactNode;
}) {
  return (
    <SlideShell>
      <header className="stagger flex flex-col gap-2">
        <Kicker>{kicker}</Kicker>
        <h2 className="font-serif text-title leading-tight">{title}</h2>
      </header>
      {children}
    </SlideShell>
  );
}

function CoverSlide() {
  const { go } = useDeck();
  return (
    <div className="slide-enter mx-auto grid min-h-full w-full max-w-6xl items-center gap-8 px-5 py-6 md:grid-cols-2 md:px-10 md:py-8">
      <div className="stagger flex flex-col gap-6">
        <Kicker>Химия · 7-сынып · І тарау</Kicker>
        <h1 className="font-serif text-display leading-[1.05] tracking-tight">
          Таза заттар және қоспалар
        </h1>
        <p className="max-w-md text-lg text-muted">
          Құрамы тұрақты зат пен аралас жүйені ажырату, қоспаны жіктеу және оны
          бөлу әдістерін меңгеру.
        </p>
        <div className="flex flex-wrap gap-2 text-sm text-muted">
          <span className="rounded-full bg-surface px-3 py-1 shadow-border">
            19 слайд
          </span>
          <span className="rounded-full bg-surface px-3 py-1 shadow-border">
            3 тапсырма
          </span>
          <span className="rounded-full bg-surface px-3 py-1 shadow-border">
            Тест · үй жұмысы
          </span>
        </div>
        <div className="flex flex-wrap gap-3">
          <Button type="button" size="lg" onClick={() => go(1)}>
            Сабақты бастау
          </Button>
          <Button type="button" size="lg" variant="outline" onClick={() => go(SLIDES.findIndex((s) => s.id === "homework"))}>
            Үй жұмысына өту
          </Button>
        </div>
        <p className="text-sm text-faint">Пернелер: ← → · Мәзір: M</p>
      </div>
      <Photo
        src="/media/hero.jpg"
        alt="Зертханалық ыдыстар: таза су, тұзды су, тұз кристалы"
      />
    </div>
  );
}

function GoalsSlide() {
  return (
    <SlideShell>
      <header className="stagger flex flex-col gap-2">
        <Kicker>Сабақтың мақсаты</Kicker>
        <h2 className="font-serif text-title leading-tight">
          Осы сабақта не үйренеміз
        </h2>
      </header>
      <ol className="stagger grid gap-3 md:grid-cols-3">
        {OBJECTIVES.map((o, i) => (
          <li key={o.code} className="rounded-2xl bg-surface p-5 shadow-border">
            <p className="font-serif text-3xl text-accent tabular-nums">{i + 1}</p>
            <p className="mt-3 text-xs font-semibold tracking-widest text-muted">
              {o.code}
            </p>
            <p className="mt-2 leading-relaxed">{o.text}</p>
          </li>
        ))}
      </ol>
      <Panel>
        <p className="text-sm text-muted">Сабақ құрылымы</p>
        <p className="mt-2">
          Анықтама → салыстыру → қоспа түрлері → бөлу әдістері → тапсырма → тест
          → үй жұмысы.
        </p>
      </Panel>
    </SlideShell>
  );
}

function NatureSlide() {
  return (
    <SlideShell>
      <header className="stagger max-w-3xl">
        <Kicker>Неге маңызды</Kicker>
        <h2 className="mt-2 font-serif text-title leading-tight">
          Табиғатта заттар таза күйінде сирек кездеседі
        </h2>
        <p className="mt-3 text-muted">
          Заттар екі түрде болады: таза түрінде және қоспа түрінде. Күнделікті
          өмірде көбіне қоспаларды кездестіреміз.
        </p>
      </header>
      <div className="grid gap-6 md:grid-cols-2">
        <Panel>
          <Droplets className="size-5 text-accent" />
          <h3 className="mt-3 font-serif text-xl">Дистилденген су</h3>
          <p className="mt-2 text-muted">
            Айдау арқылы алынған таза су. Құрамы тұрақты, тұзы жоқ. Зертханада
            және медицинада қолданылады.
          </p>
        </Panel>
        <Panel>
          <Layers className="size-5 text-accent" />
          <h3 className="mt-3 font-serif text-xl">Теңіз суы</h3>
          <p className="mt-2 text-muted">
            Су мен тұздардың біртекті қоспасы. Құрамы теңізге қарай өзгереді.
            Тұзды буландырып алуға болады.
          </p>
        </Panel>
      </div>
      <Photo
        src="/media/water.jpg"
        alt="Сол жақта мөлдір дистилденген су, оң жақта тұзды теңіз суы"
        caption="Сол: таза су. Оң: қоспа — теңіз суы."
      />
    </SlideShell>
  );
}

function PureSlide() {
  return (
    <SlideShell>
      <header className="stagger max-w-3xl">
        <Kicker>Анықтама</Kicker>
        <h2 className="mt-2 font-serif text-title leading-tight">Таза зат</h2>
        <p className="mt-3 text-lg leading-relaxed">
          Құрамы мен физикалық қасиеттері тұрақты, бір ғана заттан тұратын зат.
        </p>
      </header>
      <div className="grid gap-3 md:grid-cols-3">
        {PURE_TRAITS.map((t) => (
          <Panel key={t.title}>
            <h3 className="font-serif text-xl">{t.title}</h3>
            <p className="mt-2 text-muted">{t.body}</p>
          </Panel>
        ))}
      </div>
      <div>
        <p className="mb-3 text-sm text-muted">Мысалдар</p>
        <div className="flex flex-wrap gap-2">
          {PURE_EXAMPLES.map((e) => (
            <span
              key={e}
              className="rounded-full bg-accent px-3 py-1.5 text-sm text-accent-fg"
            >
              {e}
            </span>
          ))}
        </div>
      </div>
    </SlideShell>
  );
}

function MixtureSlide() {
  return (
    <SlideShell>
      <header className="stagger max-w-3xl">
        <Kicker>Анықтама</Kicker>
        <h2 className="mt-2 font-serif text-title leading-tight">Қоспа</h2>
        <p className="mt-3 text-lg leading-relaxed">
          Екі немесе одан көп заттың физикалық араласуы. Қоспадағы заттар өз
          қасиеттерін сақтайды.
        </p>
      </header>
      <div className="grid gap-6 md:grid-cols-2">
        <div className="grid gap-3">
          {MIX_TRAITS.map((t) => (
            <Panel key={t.title}>
              <h3 className="font-serif text-xl">{t.title}</h3>
              <p className="mt-2 text-muted">{t.body}</p>
            </Panel>
          ))}
        </div>
        <Photo
          src="/media/mixtures.jpg"
          alt="Шәй ерітіндісі мен май-су қабаттары"
          caption="Сол: біртекті шәй. Оң: әртекті май мен су."
        />
      </div>
      <div className="flex flex-wrap gap-2">
        {MIX_EXAMPLES.map((e) => (
          <span
            key={e}
            className="rounded-full bg-ink px-3 py-1.5 text-sm text-bg"
          >
            {e}
          </span>
        ))}
      </div>
    </SlideShell>
  );
}

function TableSlide() {
  return (
    <SlideShell>
      <header className="stagger">
        <Kicker>Салыстыру</Kicker>
        <h2 className="mt-2 font-serif text-title leading-tight">
          Таза зат пен қоспаның айырмасы
        </h2>
      </header>
      <div className="flex flex-col gap-3 md:hidden">
        {COMPARE_ROWS.map((row) => (
          <Panel key={row.label} className="p-4 md:p-5">
            <p className="text-xs font-semibold tracking-widest text-muted">
              {row.label}
            </p>
            <p className="mt-2">
              <span className="text-accent">Таза зат. </span>
              {row.pure}
            </p>
            <p className="mt-1">
              <span className="font-medium">Қоспа. </span>
              {row.mix}
            </p>
          </Panel>
        ))}
      </div>
      <div className="hidden overflow-hidden rounded-2xl bg-surface shadow-border md:block">
        <div className="grid grid-cols-3 border-b border-border bg-surface-2 px-4 py-3 text-sm font-semibold">
          <span>Белгісі</span>
          <span className="text-accent">Таза зат</span>
          <span className="whitespace-nowrap">Қоспа</span>
        </div>
        {COMPARE_ROWS.map((row) => (
          <div
            key={row.label}
            className="grid grid-cols-3 gap-2 border-b border-border px-4 py-4 last:border-0"
          >
            <span className="text-sm font-medium text-muted">{row.label}</span>
            <span>{row.pure}</span>
            <span>{row.mix}</span>
          </div>
        ))}
      </div>
      <p className="text-muted">
        Есте сақтаңыз: қоспаны физикалық әдіспен бөлеміз, ал қосылысты — тек
        химиялық реакциямен.
      </p>
    </SlideShell>
  );
}

function TypesSlide() {
  return (
    <SlideShell>
      <header className="stagger">
        <Kicker>Жіктеу</Kicker>
        <h2 className="mt-2 font-serif text-title leading-tight">
          Қоспаның екі түрі
        </h2>
      </header>
      <div className="grid gap-4 md:grid-cols-2">
        <Panel>
          <h3 className="font-serif text-xl">Біртекті · гомогенді</h3>
          <p className="mt-2 text-muted">
            Құрамдас бөліктері көзбен ажыратылмайды. Бүкіл көлемде біркелкі.
          </p>
          <p className="mt-3 text-sm">
            Мысал: тұз ерітіндісі, ауа, қант шәй, спирт пен су.
          </p>
          <div className="mt-4">
            <MixVisual kind="homo" label="Бөлшектер біркелкі араласқан" />
          </div>
        </Panel>
        <Panel>
          <h3 className="font-serif text-xl">Әртекті · гетерогенді</h3>
          <p className="mt-2 text-muted">
            Құрамдас бөліктерін көзбен немесе лупамен көруге болады. Қабат,
            түйір, тамшы байқалады.
          </p>
          <p className="mt-3 text-sm">
            Мысал: құм мен су, май мен су, тұман, темір мен күкірт.
          </p>
          <div className="mt-4">
            <MixVisual kind="hetero" label="Бөлшектер бөлек топталған" />
          </div>
        </Panel>
      </div>
    </SlideShell>
  );
}

function ExamplesSlide() {
  return (
    <SlideShell>
      <header className="stagger">
        <Kicker>Күнделікті өмір</Kicker>
        <h2 className="mt-2 font-serif text-title leading-tight">
          Қоршаған ортадағы қоспалар
        </h2>
      </header>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {LIFE_EXAMPLES.map((ex) => (
          <Panel key={ex.name} className="p-4 md:p-5">
            <p className="text-xs font-semibold tracking-widest text-accent">
              {ex.kind}
            </p>
            <h3 className="mt-2 font-serif text-xl">{ex.name}</h3>
            <p className="mt-2 text-sm text-muted">{ex.note}</p>
          </Panel>
        ))}
      </div>
    </SlideShell>
  );
}

function MethodsSlide() {
  const icons = {
    settle: Droplets,
    filter: Filter,
    magnet: Magnet,
    evap: Beaker,
    distill: FlaskConical,
  };
  return (
    <SlideShell>
      <header className="stagger">
        <Kicker>Әдістер</Kicker>
        <h2 className="mt-2 font-serif text-title leading-tight">
          Қоспаны бөлудің бес жолы
        </h2>
        <p className="mt-2 text-muted">
          Әдісті таңдау қоспа түріне және заттардың қасиетіне байланысты.
        </p>
      </header>
      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
        {METHODS.map((m) => {
          const Icon = icons[m.id as keyof typeof icons];
          return (
            <Panel key={m.id} className="p-4 md:p-5">
              <div className="flex items-center justify-between">
                <Icon className="size-5 text-accent" />
                <span className="rounded-full bg-surface-2 px-2.5 py-1 text-xs">
                  {m.group}
                </span>
              </div>
              <h3 className="mt-3 font-serif text-xl">{m.name}</h3>
              <p className="mt-2 text-sm text-muted">{m.basis}</p>
              <p className="mt-3 text-sm">Мысал: {m.example}</p>
            </Panel>
          );
        })}
      </div>
    </SlideShell>
  );
}

function HeteroSlide() {
  return (
    <SlideShell>
      <header className="stagger">
        <Kicker>Әртекті қоспа</Kicker>
        <h2 className="mt-2 font-serif text-title leading-tight">
          Тұндыру, сүзу, магнит
        </h2>
      </header>
      <div className="grid gap-6 md:grid-cols-2">
        <div className="flex flex-col gap-4">
          <Panel>
            <h3 className="font-serif text-xl">Тұндыру</h3>
            <p className="mt-2 text-muted">
              Ауырлық күші әсер етеді. Ауыр түйірлер түбіне шөгеді, жеңіл сұйық
              үстінде қалады. Май судан қалқып шығады.
            </p>
          </Panel>
          <Panel>
            <h3 className="font-serif text-xl">Сүзу</h3>
            <p className="mt-2 text-muted">
              Ерімейтін қатты зат сүзгіде қалады, ерітінді өтеді. Лас тұзды
              тазартудың бірінші қадамы.
            </p>
          </Panel>
          <Panel>
            <h3 className="font-serif text-xl">Магнитпен бөлу</h3>
            <p className="mt-2 text-muted">
              Темір үгіндісі магнитке жабысады, күкірт ұнтағы қалады. Әр зат өз
              қасиетін сақтайды — бұл қоспа екенінің дәлелі.
            </p>
          </Panel>
        </div>
        <div className="flex flex-col gap-4">
          <Photo
            src="/media/filtration.jpg"
            alt="Сүзгі қағазы бар құйғы және колба"
            caption="Сүзу: құм қалады, ерітінді өтеді."
          />
          <Photo
            src="/media/magnet.jpg"
            alt="Магнит темір үгіндісін күкірттен бөліп жатыр"
            caption="Магнит: темір бөлінеді, күкірт қалады."
          />
        </div>
      </div>
    </SlideShell>
  );
}

function HomoSlide() {
  return (
    <SlideShell>
      <header className="stagger">
        <Kicker>Біртекті қоспа</Kicker>
        <h2 className="mt-2 font-serif text-title leading-tight">
          Буландыру және дистилдеу
        </h2>
      </header>
      <div className="grid gap-6 md:grid-cols-2">
        <div className="flex flex-col gap-4">
          <Panel>
            <h3 className="font-serif text-xl">Буландыру · кристалдау</h3>
            <p className="mt-2 text-muted">
              Ерітіндіні қыздырғанда су ұшады, еріген зат кәрлен табақшада
              кристалл түрінде қалады. Теңіз суынан тұз осылай алынады.
            </p>
          </Panel>
          <Panel>
            <h3 className="font-serif text-xl">Дистилдеу (айдау)</h3>
            <p className="mt-2 text-muted">
              Сұйықты буландырып, буды салқындатып қайта сұйыққа айналдырады.
              Қайнау температурасы әртүрлі заттар бөлінеді. Дистилденген су
              осы әдіспен алынады.
            </p>
          </Panel>
          <Panel>
            <p className="text-sm text-muted">Есте сақтау</p>
            <p className="mt-2">
              Сүзу біртекті ерітіндіні бөлмейді — тұз бен су сүзгіден бірге
              өтеді. Сондықтан ерітіндіге буландыру немесе айдау керек.
            </p>
          </Panel>
        </div>
        <Photo
          src="/media/distillation.jpg"
          alt="Айдау қондырғысы: колба, тоңазытқыш, қабылдағыш"
          caption="Дистилдеу: бу конденсацияланып, таза сұйық жиналады."
        />
      </div>
    </SlideShell>
  );
}

function ExperimentSlide() {
  return (
    <SlideShell>
      <header className="stagger max-w-3xl">
        <Kicker>Тәжірибе</Kicker>
        <h2 className="mt-2 font-serif text-title leading-tight">
          Темір мен күкірт: қоспа және қосылыс
        </h2>
        <p className="mt-3 text-muted">
          Осы тәжірибе қоспа мен химиялық қосылыстың айырмасын көрсетеді.
        </p>
      </header>
      <div className="grid gap-4 md:grid-cols-2">
        <Panel>
          <p className="text-xs font-semibold tracking-widest text-accent">
            Қоспа
          </p>
          <h3 className="mt-2 font-serif text-xl">Fe + S араластыру</h3>
          <ul className="mt-3 flex flex-col gap-2 text-sm text-muted">
            <li className="flex gap-2">
              <Check className="mt-0.5 size-4 shrink-0 text-ok" />
              Түсі сұр-сары, әртекті
            </li>
            <li className="flex gap-2">
              <Check className="mt-0.5 size-4 shrink-0 text-ok" />
              Темір магнитке тартылады
            </li>
            <li className="flex gap-2">
              <Check className="mt-0.5 size-4 shrink-0 text-ok" />
              Әр зат өз қасиетін сақтайды
            </li>
            <li className="flex gap-2">
              <Check className="mt-0.5 size-4 shrink-0 text-ok" />
              Физикалық әдіспен бөлінеді
            </li>
          </ul>
        </Panel>
        <Panel>
          <p className="text-xs font-semibold tracking-widest text-accent">
            Қосылыс
          </p>
          <h3 className="mt-2 font-serif text-xl">Темір сульфиді FeS</h3>
          <ul className="mt-3 flex flex-col gap-2 text-sm text-muted">
            <li className="flex gap-2">
              <Check className="mt-0.5 size-4 shrink-0 text-ok" />
              Қыздырғанда жаңа зат түзіледі
            </li>
            <li className="flex gap-2">
              <Check className="mt-0.5 size-4 shrink-0 text-ok" />
              Магнитке тартылмайды
            </li>
            <li className="flex gap-2">
              <Check className="mt-0.5 size-4 shrink-0 text-ok" />
              Бастапқы қасиеттер жоғалады
            </li>
            <li className="flex gap-2">
              <Check className="mt-0.5 size-4 shrink-0 text-ok" />
              Физикалық әдіспен бөлінбейді
            </li>
          </ul>
        </Panel>
      </div>
      <Photo
        src="/media/magnet.jpg"
        alt="Магнит темірді күкірт ұнтағынан бөліп тұр"
        caption="Қоспада темір магнитке бағынады. FeS қосылысында мұндай қасиет жоқ."
      />
    </SlideShell>
  );
}

function HomeworkSlide({ teacher }: { teacher: boolean }) {
  return (
    <SlideShell>
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <Kicker>Үй жұмысы</Kicker>
          <h2 className="mt-2 font-serif text-title leading-tight">
            Бес тапсырма
          </h2>
        </div>
        <Button
          type="button"
          variant="outline"
          className="no-print"
          onClick={() => window.print()}
        >
          <Printer />
          Баспаға
        </Button>
      </header>
      <ol className="flex flex-col gap-3">
        {HOMEWORK.map((h) => (
          <li key={h.n} className="rounded-2xl bg-surface p-5 shadow-border">
            <p className="text-xs font-semibold tracking-widest text-accent">
              {h.n}-тапсырма · {h.title}
            </p>
            <p className="mt-2 leading-relaxed">{h.body}</p>
          </li>
        ))}
      </ol>
      {teacher
        ? HOMEWORK_KEYS.map((k) => (
            <Panel key={k.n}>
              <p className="text-xs font-semibold tracking-widest text-muted">
                Мұғалімге · {k.title}
              </p>
              <ul className="mt-3 flex flex-col gap-1.5 text-sm">
                {k.lines.map((line) => (
                  <li key={line}>{line}</li>
                ))}
              </ul>
            </Panel>
          ))
        : (
          <p className="text-sm text-muted no-print">
            Жауап үлгісін көру үшін төмендегі «Мұғалім» режимін қосыңыз.
          </p>
        )}
    </SlideShell>
  );
}

function GlossarySlide() {
  return (
    <SlideShell>
      <header className="stagger">
        <Kicker>Сөздік</Kicker>
        <h2 className="mt-2 font-serif text-title leading-tight">Глоссарий</h2>
      </header>
      <div className="grid gap-3 md:grid-cols-2">
        {GLOSSARY.map((g) => (
          <div key={g.term} className="rounded-2xl bg-surface p-4 shadow-border">
            <h3 className="font-serif text-lg">{g.term}</h3>
            <p className="mt-1.5 text-sm text-muted">{g.def}</p>
          </div>
        ))}
      </div>
    </SlideShell>
  );
}

function ThanksSlide() {
  const { go } = useDeck();
  return (
    <SlideShell>
      <div className="mx-auto flex max-w-2xl flex-col items-start gap-6 py-8">
        <Kicker>Сабақ соңы</Kicker>
        <h2 className="font-serif text-display leading-tight">
          Үш нәрсені есте сақтаңыз
        </h2>
        <ol className="flex flex-col gap-4">
          <li className="flex gap-3">
            <span className="font-serif text-2xl text-accent">1</span>
            <p>Таза заттың құрамы тұрақты. Қоспанікі — өзгермелі.</p>
          </li>
          <li className="flex gap-3">
            <span className="font-serif text-2xl text-accent">2</span>
            <p>Біртекті қоспада бөлшек көрінбейді, әртектіде көрінеді.</p>
          </li>
          <li className="flex gap-3">
            <span className="font-serif text-2xl text-accent">3</span>
            <p>Қоспаны физикалық әдіспен бөлеміз. Қосылысты — химиялық.</p>
          </li>
        </ol>
        <div className="flex flex-wrap gap-3">
          <Button type="button" onClick={() => go(SLIDES.findIndex((s) => s.id === "task-sort"))}>
            Тапсырмаларға оралу
          </Button>
          <Button type="button" variant="outline" onClick={() => go(0)}>
            <BookOpen />
            Басынан
          </Button>
        </div>
      </div>
    </SlideShell>
  );
}

