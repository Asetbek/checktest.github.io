import { createContext, useContext } from "react";

export type DeckApi = {
  index: number;
  go: (i: number) => void;
  next: () => void;
  prev: () => void;
  teacher: boolean;
};

export const DeckContext = createContext<DeckApi | null>(null);

export function useDeck() {
  const ctx = useContext(DeckContext);
  if (!ctx) throw new Error("useDeck must be used inside Deck");
  return ctx;
}
