import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as BookOpen, a as Minimize, c as List, d as Funnel, f as FlaskConical, g as Check, h as ChevronLeft, i as Printer, l as Layers, m as ChevronRight, o as Maximize, p as Droplets, r as RotateCcw, s as Magnet, t as X, u as GraduationCap, v as Beaker } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DIJKDqHX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[opacity,transform,background-color,color,box-shadow] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50 focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:shrink-0", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg shadow-border hover:opacity-90",
			ink: "bg-ink text-bg shadow-border hover:opacity-90",
			outline: "bg-surface text-ink shadow-border hover:bg-surface-2",
			ghost: "text-ink hover:bg-surface-2",
			muted: "bg-surface-2 text-ink hover:bg-border"
		},
		size: {
			sm: "h-9 rounded-lg px-3 text-sm [&_svg]:size-4",
			md: "h-11 rounded-xl px-4 text-sm [&_svg]:size-4",
			lg: "h-12 rounded-2xl px-5 text-base [&_svg]:size-5",
			icon: "size-11 rounded-xl [&_svg]:size-5",
			"icon-sm": "size-9 rounded-lg [&_svg]:size-4"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var SECTIONS = [
	{
		id: "intro",
		label: "Кіріспе"
	},
	{
		id: "theory",
		label: "Жаңа сабақ"
	},
	{
		id: "practice",
		label: "Тапсырмалар"
	},
	{
		id: "quiz",
		label: "Тест"
	},
	{
		id: "homework",
		label: "Үй жұмысы"
	},
	{
		id: "end",
		label: "Қорытынды"
	}
];
var SLIDES = [
	{
		id: "cover",
		section: "intro",
		kicker: "Химия · 7-сынып",
		title: "Мұқаба"
	},
	{
		id: "goals",
		section: "intro",
		kicker: "Сабақ жоспары",
		title: "Оқу мақсаты"
	},
	{
		id: "nature",
		section: "intro",
		kicker: "Неге маңызды",
		title: "Табиғаттағы заттар"
	},
	{
		id: "pure",
		section: "theory",
		kicker: "Анықтама",
		title: "Таза зат"
	},
	{
		id: "mixture",
		section: "theory",
		kicker: "Анықтама",
		title: "Қоспа"
	},
	{
		id: "table",
		section: "theory",
		kicker: "Салыстыру",
		title: "Айырмашылық"
	},
	{
		id: "types",
		section: "theory",
		kicker: "Жіктеу",
		title: "Қоспа түрлері"
	},
	{
		id: "examples",
		section: "theory",
		kicker: "Күнделікті өмір",
		title: "Мысалдар"
	},
	{
		id: "methods",
		section: "theory",
		kicker: "Әдістер",
		title: "Қоспаны бөлу"
	},
	{
		id: "hetero",
		section: "theory",
		kicker: "Әртекті қоспа",
		title: "Тұндыру, сүзу, магнит"
	},
	{
		id: "homo",
		section: "theory",
		kicker: "Біртекті қоспа",
		title: "Буландыру және айдау"
	},
	{
		id: "experiment",
		section: "theory",
		kicker: "Тәжірибе",
		title: "Темір мен күкірт"
	},
	{
		id: "task-sort",
		section: "practice",
		kicker: "Тапсырма 1",
		title: "Таза зат па, қоспа ма?"
	},
	{
		id: "task-types",
		section: "practice",
		kicker: "Тапсырма 2",
		title: "Біртекті ме, әртекті ме?"
	},
	{
		id: "task-match",
		section: "practice",
		kicker: "Тапсырма 3",
		title: "Бөлу әдісін тап"
	},
	{
		id: "quiz",
		section: "quiz",
		kicker: "Білімді тексеру",
		title: "8 сұрақты тест"
	},
	{
		id: "homework",
		section: "homework",
		kicker: "Сабақтан кейін",
		title: "Үй жұмысы"
	},
	{
		id: "glossary",
		section: "end",
		kicker: "Сөздік",
		title: "Глоссарий"
	},
	{
		id: "thanks",
		section: "end",
		kicker: "Сабақ соңы",
		title: "Қорытынды"
	}
];
var OBJECTIVES = [
	{
		code: "7.4.1.5",
		text: "Таза зат пен қоспаны ажыратып, қоспаларды біртекті және әртекті деп жіктейді."
	},
	{
		code: "7.4.1.6",
		text: "Қоспаны бөлу әдісін таңдап, тәжірибені жоспарлай алады."
	},
	{
		code: "Өмірмен байланыс",
		text: "Ас тұзын, ауаны, суды және тағамды мысалға алып, неліктен таза зат керек екенін түсіндіреді."
	}
];
var PURE_TRAITS = [
	{
		title: "Құрамы тұрақты",
		body: "Бір заттан тұрады. Молекулалары (немесе атомдары) бірдей."
	},
	{
		title: "Қасиеті тұрақты",
		body: "Қайнау, балқу температурасы, тығыздығы өзгермейді."
	},
	{
		title: "Химиялық бөлу",
		body: "Қосылысты жай заттарға тек химиялық реакциямен бөледі."
	}
];
var MIX_TRAITS = [
	{
		title: "Құрамы өзгермелі",
		body: "Екі немесе одан көп зат араласқан. Үлесі әртүрлі болуы мүмкін."
	},
	{
		title: "Қасиеті сақталады",
		body: "Әр зат өз физикалық қасиетін жоғалтпайды."
	},
	{
		title: "Физикалық бөлу",
		body: "Сүзу, тұндыру, магнит, буландыру, айдау арқылы бөлінеді."
	}
];
var PURE_EXAMPLES = [
	"Дистилденген су",
	"Алтын",
	"Қант",
	"Ас тұзы",
	"Оттегі",
	"Темір",
	"Азот",
	"Мыс"
];
var MIX_EXAMPLES = [
	"Ауа",
	"Теңіз суы",
	"Сүт",
	"Топырақ",
	"Мұнай",
	"Тұман",
	"Түтін",
	"Болат"
];
var LIFE_EXAMPLES = [
	{
		name: "Ауа",
		kind: "Біртекті қоспа",
		note: "Азот, оттегі, аргон және көмірқышқыл газы көзге біркелкі араласқан."
	},
	{
		name: "Теңіз суы",
		kind: "Біртекті қоспа",
		note: "Суда еріген тұздар. Тұзды буландыру немесе айдау арқылы бөледі."
	},
	{
		name: "Қант шәй",
		kind: "Біртекті қоспа",
		note: "Қант толық еріген. Ерітінді мөлдір, бөлшектері көрінбейді."
	},
	{
		name: "Сүт",
		kind: "Әртекті қоспа",
		note: "Май тамшылары суда үзілмеген. Уақыт өте қаймақ қабаты пайда болады."
	},
	{
		name: "Топырақ",
		kind: "Әртекті қоспа",
		note: "Құм, саз, қарашірінді, су мен ауа көзбен ажыратылады."
	},
	{
		name: "Тұман",
		kind: "Әртекті қоспа",
		note: "Ауадағы су тамшылары. Бұл — аэрозоль, әртекті жүйе."
	}
];
var METHODS = [
	{
		id: "settle",
		name: "Тұндыру",
		group: "Әртекті",
		basis: "Тығыздық айырмасы, ауырлық күші",
		example: "Құм мен су, май мен су"
	},
	{
		id: "filter",
		name: "Сүзу",
		group: "Әртекті",
		basis: "Еритін және ерімейтін заттар",
		example: "Құмды тұз ерітіндісінен бөлу"
	},
	{
		id: "magnet",
		name: "Магнитпен бөлу",
		group: "Әртекті",
		basis: "Бір зат магнитке тартылады",
		example: "Темір үгіндісі мен күкірт"
	},
	{
		id: "evap",
		name: "Буландыру · кристалдау",
		group: "Біртекті",
		basis: "Еріткіш ұшады, еріген зат қалады",
		example: "Ас тұзының ерітіндісі"
	},
	{
		id: "distill",
		name: "Дистилдеу (айдау)",
		group: "Біртекті",
		basis: "Қайнау температурасы әртүрлі",
		example: "Теңіз суынан тұщы су, спирт пен су"
	}
];
var SORT_ITEMS = [
	{
		id: "air",
		label: "Ауа",
		answer: "mix"
	},
	{
		id: "h2",
		label: "Сутегі",
		answer: "pure"
	},
	{
		id: "cu",
		label: "Мыс",
		answer: "pure"
	},
	{
		id: "milk",
		label: "Сүт",
		answer: "mix"
	},
	{
		id: "au",
		label: "Алтын",
		answer: "pure"
	},
	{
		id: "alloy",
		label: "Металл балқымалары",
		answer: "mix"
	},
	{
		id: "cl",
		label: "Хлор",
		answer: "pure"
	},
	{
		id: "sol",
		label: "Ерітінділер",
		answer: "mix"
	},
	{
		id: "n2",
		label: "Азот",
		answer: "pure"
	},
	{
		id: "fog",
		label: "Тұман",
		answer: "mix"
	},
	{
		id: "smoke",
		label: "Түтін",
		answer: "mix"
	},
	{
		id: "sugar",
		label: "Қант",
		answer: "pure"
	}
];
var TYPE_ITEMS = [
	{
		id: "saltw",
		label: "Ас тұзының ерітіндісі",
		answer: "homo"
	},
	{
		id: "sandw",
		label: "Құм және су",
		answer: "hetero"
	},
	{
		id: "air2",
		label: "Ауа",
		answer: "homo"
	},
	{
		id: "oilw",
		label: "Өсімдік майы және су",
		answer: "hetero"
	},
	{
		id: "sea",
		label: "Теңіз суы",
		answer: "homo"
	},
	{
		id: "fes",
		label: "Темір үгіндісі мен күкірт",
		answer: "hetero"
	},
	{
		id: "tea",
		label: "Қант салынған шәй",
		answer: "homo"
	},
	{
		id: "fog2",
		label: "Тұман",
		answer: "hetero"
	},
	{
		id: "soil",
		label: "Топырақ",
		answer: "hetero"
	},
	{
		id: "alc",
		label: "Спирт пен су",
		answer: "homo"
	}
];
var MATCH_ITEMS = [
	{
		id: "m1",
		mixture: "Темір үгіндісі мен күкірт ұнтағы",
		options: [
			"Магнитпен бөлу",
			"Буландыру",
			"Айдау"
		],
		answer: "Магнитпен бөлу"
	},
	{
		id: "m2",
		mixture: "Теңіз суынан тұщы су алу",
		options: [
			"Сүзу",
			"Дистилдеу (айдау)",
			"Магнитпен бөлу"
		],
		answer: "Дистилдеу (айдау)"
	},
	{
		id: "m3",
		mixture: "Құм мен су",
		options: [
			"Тұндыру немесе сүзу",
			"Айдау",
			"Кристалдау"
		],
		answer: "Тұндыру немесе сүзу"
	},
	{
		id: "m4",
		mixture: "Ас тұзының судағы ерітіндісі",
		options: [
			"Сүзу",
			"Буландыру / кристалдау",
			"Магнитпен бөлу"
		],
		answer: "Буландыру / кристалдау"
	},
	{
		id: "m5",
		mixture: "Ластанған ас тұзы (құм аралас)",
		options: [
			"Алдымен сүзу, сосын буландыру",
			"Тек магнит",
			"Тек тұндыру, басқа қадам жоқ"
		],
		answer: "Алдымен сүзу, сосын буландыру"
	}
];
var QUIZ = [
	{
		id: "q1",
		prompt: "Таза заттың құрамы қандай?",
		options: [
			"Үнемі өзгеріп отырады",
			"Тұрақты, бір заттан тұрады",
			"Тек сұйық күйде болады",
			"Тек қоспадан кейін пайда болады"
		],
		answer: 1,
		why: "Таза заттың құрамы мен физикалық қасиеттері тұрақты."
	},
	{
		id: "q2",
		prompt: "Ауа — бұл:",
		options: [
			"Таза зат",
			"Химиялық қосылыс",
			"Біртекті қоспа",
			"Әртекті қоспа"
		],
		answer: 2,
		why: "Ауа бірнеше газдың біркелкі қоспасы, сондықтан біртекті қоспа."
	},
	{
		id: "q3",
		prompt: "Қанттың суда толық еріген ерітіндісі қандай қоспа?",
		options: [
			"Әртекті",
			"Біртекті",
			"Таза зат",
			"Жай зат"
		],
		answer: 1,
		why: "Қант молекулалары көзге көрінбей біркелкі таралады — гомогенді қоспа."
	},
	{
		id: "q4",
		prompt: "Темір мен күкірт ұнтағының қоспасын қалай бөледі?",
		options: [
			"Айдау",
			"Сүзу",
			"Магнитпен",
			"Кристалдау"
		],
		answer: 2,
		why: "Темір магнитке тартылады, күкірт тартылмайды."
	},
	{
		id: "q5",
		prompt: "Теңіз суынан тұзды алудың ең қолайлы әдісі:",
		options: [
			"Магнит",
			"Буландыру",
			"Сүзу",
			"Тұндыру ғана"
		],
		answer: 1,
		why: "Су ұшып кетеді, тұз кәрлен табақшада қалады."
	},
	{
		id: "q6",
		prompt: "Тұман неге әртекті қоспаға жатады?",
		options: [
			"Ол бір ғана зат",
			"Құрамдас бөліктерін көзбен ажыратуға болады",
			"Оның құрамы тұрақты",
			"Ол магнитке тартылады"
		],
		answer: 1,
		why: "Ауадағы су тамшылары көрінеді — гетерогенді жүйе."
	},
	{
		id: "q7",
		prompt: "Дистилдеу (айдау) неге негізделген?",
		options: [
			"Магниттік қасиетке",
			"Түс айырмасына",
			"Қайнау температурасының айырмасына",
			"Иіс айырмасына"
		],
		answer: 2,
		why: "Сұйықты буландырып, сосын конденсациялайды. Қайнау температурасы әртүрлі заттар бөлінеді."
	},
	{
		id: "q8",
		prompt: "Темір сульфиді (FeS) неліктен қоспа емес?",
		options: [
			"Оны магнитпен оңай бөлуге болады",
			"Темір мен күкірт өз қасиетін толық сақтайды",
			"Жаңа зат түзілген, қасиеттері өзгеше, физикалық әдіспен бөлінбейді",
			"Ол әртекті ерітінді"
		],
		answer: 2,
		why: "FeS — химиялық қосылыс. Қоспада заттар өз қасиетін сақтайды, қосылыста сақтамайды."
	}
];
var HOMEWORK = [
	{
		n: 1,
		title: "Оқу және глоссарий",
		body: "Оқулықтан §2 «Таза заттар және қоспалар» мәтінін оқы. Дәптерге кемінде 8 терминнен глоссарий жаса: таза зат, қоспа, біртекті, әртекті, тұндыру, сүзу, буландыру, дистилдеу."
	},
	{
		n: 2,
		title: "Жіктеу кестесі",
		body: "Кесте сыз: Зат | Таза зат / қоспа | Егер қоспа болса — біртекті / әртекті. Заттар: оттегі, теңіз суы, алтын, сүт, топырақ, азот, мұнай, дистилденген су, тұман, мыс."
	},
	{
		n: 3,
		title: "Тәжірибе схемасы",
		body: "«Ластанған ас тұзын тазарту» тәжірибесінің ретін сыз. Қадамдары: суда еріту → сүзу → буландыру / кристалдау. Әр қадамда не бөлінетінін жаз."
	},
	{
		n: 4,
		title: "Үйден бақылау",
		body: "Үйден 5 қоспа тап (ас үй, ванна, аула). Әрқайсысына жаз: атауы, біртекті ме әртекті ме, қандай әдіспен бөлуге болады."
	},
	{
		n: 5,
		title: "Жазба жұмыс",
		body: "6–8 сөйлем жаз: «Неліктен ішуге таза су, тамаққа таза тұз керек?» Таза зат пен қоспа терминдерін қолдан."
	}
];
var HOMEWORK_KEYS = [{
	n: 2,
	title: "Кесте жауабы",
	lines: [
		"Оттегі — таза зат",
		"Теңіз суы — біртекті қоспа",
		"Алтын — таза зат",
		"Сүт — әртекті қоспа",
		"Топырақ — әртекті қоспа",
		"Азот — таза зат",
		"Мұнай — қоспа (көбіне әртекті деп қараймыз)",
		"Дистилденген су — таза зат",
		"Тұман — әртекті қоспа",
		"Мыс — таза зат"
	]
}, {
	n: 3,
	title: "Тазарту реті",
	lines: [
		"1. Лас тұзды суда ерітеміз — тұз ериді, құм ерімейді.",
		"2. Сүземіз — құм сүзгіде қалады, тұз ерітіндісі өтеді.",
		"3. Ерітіндіні буландырамыз — су ұшады, таза тұз кристалы қалады."
	]
}];
var GLOSSARY = [
	{
		term: "Таза зат",
		def: "Құрамы мен қасиеттері тұрақты, бір заттан тұратын зат."
	},
	{
		term: "Қоспа",
		def: "Екі немесе одан көп заттың физикалық араласуы. Заттар өз қасиетін сақтайды."
	},
	{
		term: "Біртекті (гомогенді) қоспа",
		def: "Құрамдас бөліктері көзбен ажыратылмайтын, бүкіл көлемде біркелкі қоспа."
	},
	{
		term: "Әртекті (гетерогенді) қоспа",
		def: "Құрамдас бөліктерін көзбен немесе лупамен ажыратуға болатын қоспа."
	},
	{
		term: "Тұндыру",
		def: "Тығыздығы әртүрлі заттардың ауырлық күшімен қабаттарға бөлінуі."
	},
	{
		term: "Сүзу",
		def: "Ерімейтін қатты затты сұйықтан сүзгі арқылы бөлу."
	},
	{
		term: "Буландыру",
		def: "Еріткішті ұшырып, еріген затты кристал күйінде алу."
	},
	{
		term: "Дистилдеу (айдау)",
		def: "Сұйықты буландырып, буды қайта сұйыққа айналдыру арқылы бөлу."
	},
	{
		term: "Қосылыс",
		def: "Химиялық реакция нәтижесінде түзілген жаңа зат. Физикалық әдіспен бөлінбейді."
	},
	{
		term: "Дистилденген су",
		def: "Айдау арқылы алынған таза су. Құрамында тұз жоқ."
	}
];
var COMPARE_ROWS = [
	{
		label: "Құрамы",
		pure: "Тұрақты, бір зат",
		mix: "Өзгермелі, бірнеше зат"
	},
	{
		label: "Қасиеттері",
		pure: "Тұрақты (балқу, қайнау t°)",
		mix: "Әр зат өз қасиетін сақтайды"
	},
	{
		label: "Бөлу тәсілі",
		pure: "Химиялық реакция",
		mix: "Физикалық әдістер"
	},
	{
		label: "Мысал",
		pure: "Алтын, қант, оттегі",
		mix: "Ауа, теңіз суы, топырақ"
	}
];
function useChoices(key) {
	const [choices, setChoices] = (0, import_react.useState)({});
	const [checked, setChecked] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(key);
			if (raw) {
				const parsed = JSON.parse(raw);
				setChoices(parsed.choices ?? {});
				setChecked(Boolean(parsed.checked));
			}
		} catch {}
	}, [key]);
	(0, import_react.useEffect)(() => {
		localStorage.setItem(key, JSON.stringify({
			choices,
			checked
		}));
	}, [
		key,
		choices,
		checked
	]);
	return {
		choices,
		setChoices,
		checked,
		setChecked
	};
}
function cycleValue(current, values) {
	return values[((current ? values.indexOf(current) : -1) + 1) % values.length];
}
function ScoreBar({ correct, total, onReset }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm text-muted",
			children: [
				"Нәтиже:",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-semibold text-ink tabular-nums",
					children: [
						correct,
						" / ",
						total
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			type: "button",
			variant: "ghost",
			size: "sm",
			onClick: onReset,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Қайталау"]
		})]
	});
}
function SortTask({ teacher }) {
	const { choices, setChoices, checked, setChecked } = useChoices("chem7-sort");
	const bins = [{
		id: "pure",
		label: "Таза зат"
	}, {
		id: "mix",
		label: "Қоспа"
	}];
	const correct = SORT_ITEMS.filter((it) => choices[it.id] === it.answer).length;
	const show = checked || teacher;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "Затты басыңыз: таза зат пен қоспа арасында ауысады. Сосын тексеріңіз."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: bins.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("rounded-full px-3 py-1 text-sm", b.id === "pure" ? "bg-accent text-accent-fg" : "bg-ink text-bg"),
					children: b.label
				}, b.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: SORT_ITEMS.map((it) => {
					const val = choices[it.id];
					const ok = val === it.answer;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							setChecked(false);
							setChoices((c) => ({
								...c,
								[it.id]: cycleValue(c[it.id], ["pure", "mix"])
							}));
						},
						className: cn("h-11 rounded-xl px-3.5 text-sm font-medium shadow-border transition-[background-color,color,opacity] duration-[var(--motion-quick)]", val === "pure" && "bg-accent text-accent-fg", val === "mix" && "bg-ink text-bg", !val && "bg-surface text-ink", show && val && !ok && "ring-2 ring-bad", show && val && ok && "ring-2 ring-ok"),
						children: it.label
					}, it.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: () => setChecked(true),
					children: "Тексеру"
				}), show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreBar, {
					correct,
					total: SORT_ITEMS.length,
					onReset: () => {
						setChoices({});
						setChecked(false);
					}
				}) : null]
			})
		]
	});
}
function TypeTask({ teacher }) {
	const { choices, setChoices, checked, setChecked } = useChoices("chem7-types");
	const show = checked || teacher;
	const correct = TYPE_ITEMS.filter((it) => choices[it.id] === it.answer).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "Қоспаны басыңыз: біртекті мен әртекті арасында ауысады."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-accent px-3 py-1 text-sm text-accent-fg",
					children: "Біртекті"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-ink px-3 py-1 text-sm text-bg",
					children: "Әртекті"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2 sm:grid-cols-2",
				children: TYPE_ITEMS.map((it) => {
					const val = choices[it.id];
					const ok = val === it.answer;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setChecked(false);
							setChoices((c) => ({
								...c,
								[it.id]: cycleValue(c[it.id], ["homo", "hetero"])
							}));
						},
						className: cn("flex h-12 items-center justify-between rounded-xl px-4 text-left text-sm font-medium shadow-border", val === "homo" && "bg-accent text-accent-fg", val === "hetero" && "bg-ink text-bg", !val && "bg-surface text-ink", show && val && !ok && "ring-2 ring-bad", show && val && ok && "ring-2 ring-ok"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: it.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs opacity-80",
							children: val === "homo" ? "біртекті" : val === "hetero" ? "әртекті" : "—"
						})]
					}, it.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: () => setChecked(true),
					children: "Тексеру"
				}), show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreBar, {
					correct,
					total: TYPE_ITEMS.length,
					onReset: () => {
						setChoices({});
						setChecked(false);
					}
				}) : null]
			})
		]
	});
}
function MatchTask({ teacher }) {
	const { choices, setChoices, checked, setChecked } = useChoices("chem7-match");
	const show = checked || teacher;
	const correct = MATCH_ITEMS.filter((it) => choices[it.id] === it.answer).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [MATCH_ITEMS.map((it) => {
			const val = choices[it.id];
			const ok = val === it.answer;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl bg-surface p-4 shadow-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 font-medium",
					children: it.mixture
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-2",
					children: it.options.map((opt) => {
						const selected = val === opt;
						const isAnswer = opt === it.answer;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								setChecked(false);
								setChoices((c) => ({
									...c,
									[it.id]: opt
								}));
							},
							className: cn("flex min-h-11 items-center justify-between rounded-xl px-3 text-left text-sm shadow-border", selected ? "bg-accent text-accent-fg" : "bg-bg text-ink", show && isAnswer && "ring-2 ring-ok", show && selected && !ok && "ring-2 ring-bad"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: opt }),
								show && isAnswer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : null,
								show && selected && !ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }) : null
							]
						}, opt);
					})
				})]
			}, it.id);
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				onClick: () => setChecked(true),
				children: "Тексеру"
			}), show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreBar, {
				correct,
				total: MATCH_ITEMS.length,
				onReset: () => {
					setChoices({});
					setChecked(false);
				}
			}) : null]
		})]
	});
}
function QuizTask({ teacher }) {
	const [i, setI] = (0, import_react.useState)(0);
	const [picked, setPicked] = (0, import_react.useState)({});
	const [done, setDone] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem("chem7-quiz");
			if (raw) {
				const parsed = JSON.parse(raw);
				setPicked(parsed.picked ?? {});
				setDone(Boolean(parsed.done));
				setI(parsed.i ?? 0);
			}
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		localStorage.setItem("chem7-quiz", JSON.stringify({
			picked,
			done,
			i
		}));
	}, [
		picked,
		done,
		i
	]);
	const q = QUIZ[i];
	const score = (0, import_react.useMemo)(() => QUIZ.filter((item) => picked[item.id] === item.answer).length, [picked]);
	if (done || teacher) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl bg-accent px-5 py-6 text-accent-fg",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-widest",
						children: "Нәтиже"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 font-serif text-display tabular-nums leading-none",
						children: [
							score,
							"/",
							QUIZ.length
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-accent-fg/80",
						children: score >= 7 ? "Керемет. Тақырыпты берік меңгердіңіз." : score >= 5 ? "Жақсы. Қателескен сұрақтарды глоссариймен салыстырыңыз." : "Қайталап шығыңыз. Сабақ слайдтарына оралыңыз."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-3",
				children: QUIZ.map((item, idx) => {
					const sel = picked[item.id];
					const ok = sel === item.answer;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-surface p-4 shadow-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm font-medium",
								children: [
									idx + 1,
									". ",
									item.prompt
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: cn("mt-2 text-sm", ok ? "text-ok" : sel === void 0 ? "text-muted" : "text-bad"),
								children: ["Сіздің жауабыңыз: ", sel === void 0 ? "—" : item.options[sel]]
							}),
							!ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-ink",
								children: ["Дұрысы: ", item.options[item.answer]]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: item.why
							})
						]
					}, item.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "outline",
				onClick: () => {
					setPicked({});
					setDone(false);
					setI(0);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Тестті қайта бастау"]
			})
		]
	});
	const selected = picked[q.id];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted tabular-nums",
				children: [
					"Сұрақ ",
					i + 1,
					" / ",
					QUIZ.length
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-title leading-snug",
				children: q.prompt
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-2",
				children: q.options.map((opt, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setPicked((p) => ({
						...p,
						[q.id]: idx
					})),
					className: cn("min-h-12 rounded-xl px-4 py-3 text-left text-sm shadow-border", selected === idx ? "bg-accent text-accent-fg" : "bg-surface text-ink"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mr-2 font-semibold tabular-nums",
						children: [idx + 1, "."]
					}), opt]
				}, opt))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					disabled: i === 0,
					onClick: () => setI((n) => Math.max(0, n - 1)),
					children: "Артқа"
				}), i < QUIZ.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					disabled: selected === void 0,
					onClick: () => setI((n) => n + 1),
					children: "Келесі сұрақ"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					disabled: selected === void 0,
					onClick: () => setDone(true),
					children: "Нәтижені көру"
				})]
			})
		]
	});
}
function Kicker({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs font-semibold tracking-widest text-accent",
		children
	});
}
function Panel({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-2xl bg-surface p-5 shadow-border md:p-6", className),
		children
	});
}
function Photo({ src, alt, caption, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: cn("min-w-0", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt,
			className: "aspect-video w-full rounded-xl object-cover"
		}), caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
			className: "mt-2 text-sm text-muted",
			children: caption
		}) : null]
	});
}
function MixVisual({ kind, label }) {
	const cells = Array.from({ length: 48 }, (_, i) => {
		const col = i % 8;
		const row = Math.floor(i / 8);
		if (kind === "pure") return "a";
		if (kind === "homo") return (col + row) % 2 === 0 ? "a" : "b";
		return col < 4 ? row + col < 7 ? "a" : "b" : "b";
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface-2 p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-8 gap-2",
			children: cells.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("aspect-square rounded-full", c === "a" ? "bg-accent" : "bg-ink/35") }, i))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-center text-sm text-muted",
			children: label
		})]
	});
}
function SlideShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "slide-enter mx-auto flex w-full max-w-6xl flex-col gap-6 px-5 py-6 md:px-10 md:py-8",
		children
	}, "shell");
}
var DeckContext = (0, import_react.createContext)(null);
function useDeck() {
	const ctx = (0, import_react.useContext)(DeckContext);
	if (!ctx) throw new Error("useDeck must be used inside Deck");
	return ctx;
}
function SlideView({ id, teacher }) {
	switch (id) {
		case "cover": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoverSlide, {});
		case "goals": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoalsSlide, {});
		case "nature": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NatureSlide, {});
		case "pure": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PureSlide, {});
		case "mixture": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MixtureSlide, {});
		case "table": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableSlide, {});
		case "types": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypesSlide, {});
		case "examples": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExamplesSlide, {});
		case "methods": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MethodsSlide, {});
		case "hetero": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeteroSlide, {});
		case "homo": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomoSlide, {});
		case "experiment": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExperimentSlide, {});
		case "task-sort": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskFrame, {
			kicker: "Тапсырма 1",
			title: "Таза зат па, қоспа ма?",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortTask, { teacher })
		});
		case "task-types": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskFrame, {
			kicker: "Тапсырма 2",
			title: "Біртекті ме, әртекті ме?",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypeTask, { teacher })
		});
		case "task-match": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskFrame, {
			kicker: "Тапсырма 3",
			title: "Қоспаны қалай бөлеміз?",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchTask, { teacher })
		});
		case "quiz": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskFrame, {
			kicker: "Тест",
			title: "Сегіз сұрақ",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizTask, { teacher })
		});
		case "homework": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeworkSlide, { teacher });
		case "glossary": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlossarySlide, {});
		case "thanks": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThanksSlide, {});
		default: return null;
	}
}
function TaskFrame({ kicker, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SlideShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "stagger flex flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: kicker }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-serif text-title leading-tight",
			children: title
		})]
	}), children] });
}
function CoverSlide() {
	const { go } = useDeck();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "slide-enter mx-auto grid min-h-full w-full max-w-6xl items-center gap-8 px-5 py-6 md:grid-cols-2 md:px-10 md:py-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "stagger flex flex-col gap-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Химия · 7-сынып · І тарау" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-display leading-[1.05] tracking-tight",
					children: "Таза заттар және қоспалар"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-md text-lg text-muted",
					children: "Құрамы тұрақты зат пен аралас жүйені ажырату, қоспаны жіктеу және оны бөлу әдістерін меңгеру."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-surface px-3 py-1 shadow-border",
							children: "19 слайд"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-surface px-3 py-1 shadow-border",
							children: "3 тапсырма"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-surface px-3 py-1 shadow-border",
							children: "Тест · үй жұмысы"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						size: "lg",
						onClick: () => go(1),
						children: "Сабақты бастау"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						size: "lg",
						variant: "outline",
						onClick: () => go(SLIDES.findIndex((s) => s.id === "homework")),
						children: "Үй жұмысына өту"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-faint",
					children: "Пернелер: ← → · Мәзір: M"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
			src: "/media/hero.jpg",
			alt: "Зертханалық ыдыстар: таза су, тұзды су, тұз кристалы"
		})]
	});
}
function GoalsSlide() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SlideShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "stagger flex flex-col gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Сабақтың мақсаты" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-title leading-tight",
				children: "Осы сабақта не үйренеміз"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "stagger grid gap-3 md:grid-cols-3",
			children: OBJECTIVES.map((o, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-2xl bg-surface p-5 shadow-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-serif text-3xl text-accent tabular-nums",
						children: i + 1
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs font-semibold tracking-widest text-muted",
						children: o.code
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 leading-relaxed",
						children: o.text
					})
				]
			}, o.code))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Сабақ құрылымы"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2",
			children: "Анықтама → салыстыру → қоспа түрлері → бөлу әдістері → тапсырма → тест → үй жұмысы."
		})] })
	] });
}
function NatureSlide() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SlideShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "stagger max-w-3xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Неге маңызды" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-serif text-title leading-tight",
					children: "Табиғатта заттар таза күйінде сирек кездеседі"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted",
					children: "Заттар екі түрде болады: таза түрінде және қоспа түрінде. Күнделікті өмірде көбіне қоспаларды кездестіреміз."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Droplets, { className: "size-5 text-accent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-3 font-serif text-xl",
					children: "Дистилденген су"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "Айдау арқылы алынған таза су. Құрамы тұрақты, тұзы жоқ. Зертханада және медицинада қолданылады."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-5 text-accent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-3 font-serif text-xl",
					children: "Теңіз суы"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "Су мен тұздардың біртекті қоспасы. Құрамы теңізге қарай өзгереді. Тұзды буландырып алуға болады."
				})
			] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
			src: "/media/water.jpg",
			alt: "Сол жақта мөлдір дистилденген су, оң жақта тұзды теңіз суы",
			caption: "Сол: таза су. Оң: қоспа — теңіз суы."
		})
	] });
}
function PureSlide() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SlideShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "stagger max-w-3xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Анықтама" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-serif text-title leading-tight",
					children: "Таза зат"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-lg leading-relaxed",
					children: "Құрамы мен физикалық қасиеттері тұрақты, бір ғана заттан тұратын зат."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 md:grid-cols-3",
			children: PURE_TRAITS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-serif text-xl",
				children: t.title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: t.body
			})] }, t.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-3 text-sm text-muted",
			children: "Мысалдар"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-2",
			children: PURE_EXAMPLES.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full bg-accent px-3 py-1.5 text-sm text-accent-fg",
				children: e
			}, e))
		})] })
	] });
}
function MixtureSlide() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SlideShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "stagger max-w-3xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Анықтама" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-serif text-title leading-tight",
					children: "Қоспа"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-lg leading-relaxed",
					children: "Екі немесе одан көп заттың физикалық араласуы. Қоспадағы заттар өз қасиеттерін сақтайды."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: MIX_TRAITS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-serif text-xl",
					children: t.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: t.body
				})] }, t.title))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
				src: "/media/mixtures.jpg",
				alt: "Шәй ерітіндісі мен май-су қабаттары",
				caption: "Сол: біртекті шәй. Оң: әртекті май мен су."
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-2",
			children: MIX_EXAMPLES.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full bg-ink px-3 py-1.5 text-sm text-bg",
				children: e
			}, e))
		})
	] });
}
function TableSlide() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SlideShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "stagger",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Салыстыру" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 font-serif text-title leading-tight",
				children: "Таза зат пен қоспаның айырмасы"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col gap-3 md:hidden",
			children: COMPARE_ROWS.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-4 md:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-widest text-muted",
						children: row.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-accent",
							children: "Таза зат. "
						}), row.pure]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "Қоспа. "
						}), row.mix]
					})
				]
			}, row.label))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "hidden overflow-hidden rounded-2xl bg-surface shadow-border md:block",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 border-b border-border bg-surface-2 px-4 py-3 text-sm font-semibold",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Белгісі" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-accent",
						children: "Таза зат"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Қоспа" })
				]
			}), COMPARE_ROWS.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2 border-b border-border px-4 py-4 last:border-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-medium text-muted",
						children: row.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.pure }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.mix })
				]
			}, row.label))]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "Есте сақтаңыз: қоспаны физикалық әдіспен бөлеміз, ал қосылысты — тек химиялық реакциямен."
		})
	] });
}
function TypesSlide() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SlideShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "stagger",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Жіктеу" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-2 font-serif text-title leading-tight",
			children: "Қоспаның екі түрі"
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 md:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-serif text-xl",
				children: "Біртекті · гомогенді"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: "Құрамдас бөліктері көзбен ажыратылмайды. Бүкіл көлемде біркелкі."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm",
				children: "Мысал: тұз ерітіндісі, ауа, қант шәй, спирт пен су."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MixVisual, {
					kind: "homo",
					label: "Бөлшектер біркелкі араласқан"
				})
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-serif text-xl",
				children: "Әртекті · гетерогенді"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: "Құрамдас бөліктерін көзбен немесе лупамен көруге болады. Қабат, түйір, тамшы байқалады."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm",
				children: "Мысал: құм мен су, май мен су, тұман, темір мен күкірт."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MixVisual, {
					kind: "hetero",
					label: "Бөлшектер бөлек топталған"
				})
			})
		] })]
	})] });
}
function ExamplesSlide() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SlideShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "stagger",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Күнделікті өмір" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-2 font-serif text-title leading-tight",
			children: "Қоршаған ортадағы қоспалар"
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
		children: LIFE_EXAMPLES.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "p-4 md:p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-widest text-accent",
					children: ex.kind
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-2 font-serif text-xl",
					children: ex.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: ex.note
				})
			]
		}, ex.name))
	})] });
}
function MethodsSlide() {
	const icons = {
		settle: Droplets,
		filter: Funnel,
		magnet: Magnet,
		evap: Beaker,
		distill: FlaskConical
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SlideShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "stagger",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Әдістер" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 font-serif text-title leading-tight",
				children: "Қоспаны бөлудің бес жолы"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: "Әдісті таңдау қоспа түріне және заттардың қасиетіне байланысты."
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-3 md:grid-cols-2 lg:grid-cols-3",
		children: METHODS.map((m) => {
			const Icon = icons[m.id];
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-4 md:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-surface-2 px-2.5 py-1 text-xs",
							children: m.group
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-3 font-serif text-xl",
						children: m.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: m.basis
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm",
						children: ["Мысал: ", m.example]
					})
				]
			}, m.id);
		})
	})] });
}
function HeteroSlide() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SlideShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "stagger",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Әртекті қоспа" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-2 font-serif text-title leading-tight",
			children: "Тұндыру, сүзу, магнит"
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 md:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-serif text-xl",
					children: "Тұндыру"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "Ауырлық күші әсер етеді. Ауыр түйірлер түбіне шөгеді, жеңіл сұйық үстінде қалады. Май судан қалқып шығады."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-serif text-xl",
					children: "Сүзу"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "Ерімейтін қатты зат сүзгіде қалады, ерітінді өтеді. Лас тұзды тазартудың бірінші қадамы."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-serif text-xl",
					children: "Магнитпен бөлу"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "Темір үгіндісі магнитке жабысады, күкірт ұнтағы қалады. Әр зат өз қасиетін сақтайды — бұл қоспа екенінің дәлелі."
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
				src: "/media/filtration.jpg",
				alt: "Сүзгі қағазы бар құйғы және колба",
				caption: "Сүзу: құм қалады, ерітінді өтеді."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
				src: "/media/magnet.jpg",
				alt: "Магнит темір үгіндісін күкірттен бөліп жатыр",
				caption: "Магнит: темір бөлінеді, күкірт қалады."
			})]
		})]
	})] });
}
function HomoSlide() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SlideShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "stagger",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Біртекті қоспа" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-2 font-serif text-title leading-tight",
			children: "Буландыру және дистилдеу"
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 md:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-serif text-xl",
					children: "Буландыру · кристалдау"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "Ерітіндіні қыздырғанда су ұшады, еріген зат кәрлен табақшада кристалл түрінде қалады. Теңіз суынан тұз осылай алынады."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-serif text-xl",
					children: "Дистилдеу (айдау)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "Сұйықты буландырып, буды салқындатып қайта сұйыққа айналдырады. Қайнау температурасы әртүрлі заттар бөлінеді. Дистилденген су осы әдіспен алынады."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Есте сақтау"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2",
					children: "Сүзу біртекті ерітіндіні бөлмейді — тұз бен су сүзгіден бірге өтеді. Сондықтан ерітіндіге буландыру немесе айдау керек."
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
			src: "/media/distillation.jpg",
			alt: "Айдау қондырғысы: колба, тоңазытқыш, қабылдағыш",
			caption: "Дистилдеу: бу конденсацияланып, таза сұйық жиналады."
		})]
	})] });
}
function ExperimentSlide() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SlideShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "stagger max-w-3xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Тәжірибе" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-serif text-title leading-tight",
					children: "Темір мен күкірт: қоспа және қосылыс"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted",
					children: "Осы тәжірибе қоспа мен химиялық қосылыстың айырмасын көрсетеді."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-widest text-accent",
					children: "Қоспа"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-2 font-serif text-xl",
					children: "Fe + S араластыру"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 flex flex-col gap-2 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0 text-ok" }), "Түсі сұр-сары, әртекті"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0 text-ok" }), "Темір магнитке тартылады"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0 text-ok" }), "Әр зат өз қасиетін сақтайды"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0 text-ok" }), "Физикалық әдіспен бөлінеді"]
						})
					]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-widest text-accent",
					children: "Қосылыс"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-2 font-serif text-xl",
					children: "Темір сульфиді FeS"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-3 flex flex-col gap-2 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0 text-ok" }), "Қыздырғанда жаңа зат түзіледі"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0 text-ok" }), "Магнитке тартылмайды"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0 text-ok" }), "Бастапқы қасиеттер жоғалады"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0 text-ok" }), "Физикалық әдіспен бөлінбейді"]
						})
					]
				})
			] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
			src: "/media/magnet.jpg",
			alt: "Магнит темірді күкірт ұнтағынан бөліп тұр",
			caption: "Қоспада темір магнитке бағынады. FeS қосылысында мұндай қасиет жоқ."
		})
	] });
}
function HomeworkSlide({ teacher }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SlideShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex flex-wrap items-end justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Үй жұмысы" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 font-serif text-title leading-tight",
				children: "Бес тапсырма"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "outline",
				className: "no-print",
				onClick: () => window.print(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {}), "Баспаға"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "flex flex-col gap-3",
			children: HOMEWORK.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-2xl bg-surface p-5 shadow-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-semibold tracking-widest text-accent",
					children: [
						h.n,
						"-тапсырма · ",
						h.title
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 leading-relaxed",
					children: h.body
				})]
			}, h.n))
		}),
		teacher ? HOMEWORK_KEYS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs font-semibold tracking-widest text-muted",
			children: ["Мұғалімге · ", k.title]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 flex flex-col gap-1.5 text-sm",
			children: k.lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, line))
		})] }, k.n)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted no-print",
			children: "Жауап үлгісін көру үшін төмендегі «Мұғалім» режимін қосыңыз."
		})
	] });
}
function GlossarySlide() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SlideShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "stagger",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Сөздік" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-2 font-serif text-title leading-tight",
			children: "Глоссарий"
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-3 md:grid-cols-2",
		children: GLOSSARY.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl bg-surface p-4 shadow-border",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-serif text-lg",
				children: g.term
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1.5 text-sm text-muted",
				children: g.def
			})]
		}, g.term))
	})] });
}
function ThanksSlide() {
	const { go } = useDeck();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlideShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-2xl flex-col items-start gap-6 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Сабақ соңы" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-display leading-tight",
				children: "Үш нәрсені есте сақтаңыз"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "flex flex-col gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-serif text-2xl text-accent",
							children: "1"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Таза заттың құрамы тұрақты. Қоспанікі — өзгермелі." })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-serif text-2xl text-accent",
							children: "2"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Біртекті қоспада бөлшек көрінбейді, әртектіде көрінеді." })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-serif text-2xl text-accent",
							children: "3"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Қоспаны физикалық әдіспен бөлеміз. Қосылысты — химиялық." })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: () => go(SLIDES.findIndex((s) => s.id === "task-sort")),
					children: "Тапсырмаларға оралу"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "outline",
					onClick: () => go(0),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, {}), "Басынан"]
				})]
			})
		]
	}) });
}
var INDEX_KEY = "chem7-slide";
function Deck() {
	const [index, setIndex] = (0, import_react.useState)(0);
	const [teacher, setTeacher] = (0, import_react.useState)(false);
	const [menu, setMenu] = (0, import_react.useState)(false);
	const [fullscreen, setFullscreen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			const saved = Number(localStorage.getItem(INDEX_KEY));
			if (Number.isFinite(saved) && saved >= 0 && saved < SLIDES.length) setIndex(saved);
			setTeacher(localStorage.getItem("chem7-teacher") === "1");
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		localStorage.setItem(INDEX_KEY, String(index));
	}, [index]);
	(0, import_react.useEffect)(() => {
		localStorage.setItem("chem7-teacher", teacher ? "1" : "0");
	}, [teacher]);
	const go = (0, import_react.useCallback)((i) => {
		setIndex(Math.min(SLIDES.length - 1, Math.max(0, i)));
		setMenu(false);
	}, []);
	const next = (0, import_react.useCallback)(() => go(index + 1), [go, index]);
	const prev = (0, import_react.useCallback)(() => go(index - 1), [go, index]);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA") return;
			if (e.key === "ArrowRight" || e.key === "PageDown") {
				e.preventDefault();
				next();
			} else if (e.key === "ArrowLeft" || e.key === "PageUp") {
				e.preventDefault();
				prev();
			} else if (e.key === "Home") go(0);
			else if (e.key === "End") go(SLIDES.length - 1);
			else if (e.key === "Escape") setMenu(false);
			else if (e.key === "m" || e.key === "M" || e.key === "ь") setMenu((v) => !v);
			else if (e.key === "t" || e.key === "T") setTeacher((v) => !v);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		go,
		next,
		prev
	]);
	(0, import_react.useEffect)(() => {
		const onFs = () => setFullscreen(Boolean(document.fullscreenElement));
		document.addEventListener("fullscreenchange", onFs);
		return () => document.removeEventListener("fullscreenchange", onFs);
	}, []);
	const api = (0, import_react.useMemo)(() => ({
		index,
		go,
		next,
		prev,
		teacher
	}), [
		index,
		go,
		next,
		prev,
		teacher
	]);
	const slide = SLIDES[index];
	const progress = (index + 1) / SLIDES.length * 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeckContext.Provider, {
		value: api,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "paper-bg flex h-dvh flex-col text-ink",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "no-print relative z-20 flex h-14 shrink-0 items-center gap-3 border-b border-border px-3 md:px-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "icon-sm",
							"aria-label": "Слайдтар тізімі",
							onClick: () => setMenu(true),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm font-medium",
								children: slide.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xs text-muted",
								children: slide.kicker
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: teacher ? "primary" : "ghost",
							size: "sm",
							className: "hidden sm:inline-flex",
							onClick: () => setTeacher((v) => !v),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, {}), "Мұғалім"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "icon-sm",
							"aria-label": fullscreen ? "Толық экраннан шығу" : "Толық экран",
							onClick: () => {
								if (document.fullscreenElement) document.exitFullscreen();
								else document.documentElement.requestFullscreen();
							},
							children: fullscreen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minimize, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "hidden tabular-nums text-sm text-muted md:inline",
							children: [
								index + 1,
								"/",
								SLIDES.length
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-x-0 bottom-0 h-px bg-border",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-px bg-accent transition-[width] duration-[var(--motion-fast)] ease-[var(--ease-out)]",
								style: { width: `${progress}%` }
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "min-h-0 flex-1 overflow-y-auto",
					onTouchStart: (e) => {
						const t = e.changedTouches[0];
						e.currentTarget.dataset.sx = String(t.clientX);
						e.currentTarget.dataset.sy = String(t.clientY);
					},
					onTouchEnd: (e) => {
						const el = e.currentTarget;
						const sx = Number(el.dataset.sx ?? 0);
						const sy = Number(el.dataset.sy ?? 0);
						const t = e.changedTouches[0];
						const dx = t.clientX - sx;
						const dy = t.clientY - sy;
						if (Math.abs(dx) > 72 && Math.abs(dx) > Math.abs(dy) * 1.4) {
							if (dx < 0) next();
							else prev();
						}
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlideView, {
						id: slide.id,
						teacher
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					className: "no-print flex h-16 shrink-0 items-center gap-2 border-t border-border px-3 md:px-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							size: "icon",
							"aria-label": "Алдыңғы слайд",
							disabled: index === 0,
							onClick: prev,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex min-w-0 flex-1 justify-center gap-1 overflow-x-auto py-1",
							children: SLIDES.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": `${i + 1}. ${s.title}`,
								onClick: () => go(i),
								className: cn("h-2.5 w-2.5 shrink-0 rounded-full transition-colors duration-[var(--motion-quick)]", i === index ? "bg-accent" : "bg-border hover:bg-muted")
							}, s.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "primary",
							className: "min-w-11",
							disabled: index === SLIDES.length - 1,
							onClick: next,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "Келесі"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {})]
						})
					]
				}),
				menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "no-print fixed inset-0 z-40",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "absolute inset-0 bg-ink/30",
						"aria-label": "Мәзірді жабу",
						onClick: () => setMenu(false)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "absolute inset-y-0 left-0 flex w-[min(100%,22rem)] flex-col bg-surface shadow-border",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex h-14 items-center justify-between border-b border-border px-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: "Слайдтар"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "icon-sm",
								"aria-label": "Жабу",
								onClick: () => setMenu(false),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "flex-1 overflow-y-auto p-3",
							children: SECTIONS.map((sec) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "px-2 pb-1 text-xs font-semibold tracking-widest text-muted",
									children: sec.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "flex flex-col gap-1",
									children: SLIDES.filter((s) => s.section === sec.id).map((s) => {
										const i = SLIDES.findIndex((x) => x.id === s.id);
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => go(i),
											className: cn("flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm", i === index ? "bg-accent text-accent-fg" : "hover:bg-surface-2"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "w-5 tabular-nums text-xs opacity-70",
												children: i + 1
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "min-w-0 flex-1 truncate",
												children: s.title
											})]
										}) }, s.id);
									})
								})]
							}, sec.id))
						})]
					})]
				}) : null
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Deck, {});
}
//#endregion
export { Home as component };
